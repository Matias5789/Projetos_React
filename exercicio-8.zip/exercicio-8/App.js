import React, { Component } from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';



function App(){
  return(
    <View style={styles.container}>
     <Text style={styles.vagas}> Vagas </Text>
      <ScrollView>
        <View style={styles.box1}>
          <Text style={styles.funcao}> Desenvolvedor de Software </Text>
          <Text style={styles.salario}> Salario: R$ 3.500,00 </Text>
          <Text style={styles.descricao}> Descrição: cria, testa, e mantém programas de computador, aplicativos, e sistemas.  </Text>
          <Text style={styles.contato}> Contato: (11) 951753-2846 - Whatsapp </Text>

        </View>
        <View style={styles.box2}>
          <Text style={styles.funcao}> Desenvolvedor Mobile </Text>
          <Text style={styles.salario}> Salario: R$ 4.000,00 </Text>
          <Text style={styles.descricao}> Descrição: cria aplicativos para dispositivos móveis, como smartphones e tablets. Ele escreve códigos, testa, depura e mantém os aplicativos.  </Text>
          <Text style={styles.contato}> Contato: (11) 951753-2846 - Whatsapp  </Text>

        </View>
        <View style={styles.box3}>
          <Text style={styles.funcao}> Analista de Dados </Text>
          <Text style={styles.salario}> Salario: R$ 3.700,00 </Text>
          <Text style={styles.descricao}> Descrição: coleta, analisa e interpreta dados para ajudar empresas a tomar decisões baseadas em evidências. </Text>
          <Text style={styles.contato}> Contato: (11) 951753-2846 - Whatsapp   </Text>

        </View>
        <View style={styles.box4}>
          <Text style={styles.funcao}> Web Design </Text>
          <Text style={styles.salario}> Salario: R$ 2.800,00 </Text>
          <Text style={styles.descricao}> Descrição: projetar o layout e a estética de sites. Isso inclui codificação, design, construção de interface e navegação. </Text>
          <Text style={styles.contato}> Contato: (11) 951753-2846 - Whatsapp  </Text>

        </View>
      </ScrollView>
    </View>
  )
}




const styles = StyleSheet.create({
  container:{
    flex: 1
  },
  box1:{
    backgroundColor: 'lightgray',
    height: 310,
    padding: 20,
    margin: 20,
    borderRadius: 50,
  },
  box2:{
    backgroundColor: 'lightgray',
    height: 310,
    padding: 20,
    margin: 20,
    borderRadius: 50,
  },
  box3:{
    backgroundColor: 'lightgray',
    height: 300,
    padding: 20,
    margin: 20,
    borderRadius: 50,
  },
  box4:{
    backgroundColor: 'lightgray',
    height: 300,
    padding: 20,
    margin: 20,
    borderRadius: 50,
  },
  vagas:{
    color: 'red',
    fontSize: 40,
    textAlign: 'center',
  },
  funcao:{
    color: 'blue',
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  salario: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  descricao: {
    fontSize: 20,
    marginBottom: 10,
    
  },
  contato: {
    fontSize: 20,
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  }
})




export default App;


