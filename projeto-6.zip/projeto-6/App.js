import React, { useState } from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';

export default function App() {
  // Estado para armazenar o número gerado
  const [numeroAleatorio, setNumeroAleatorio] = useState(null);

  // Função para gerar o número aleatório entre 0 e 10
  const gerarNumeroAleatorio = () => {
    const numero = Math.floor(Math.random() * 11);
    setNumeroAleatorio(numero);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Jogo de Gerador de Número Aleatório</Text>

      <Button title="Gerar Número" onPress={gerarNumeroAleatorio} />

      {numeroAleatorio !== null && (
        <Text style={styles.resultado}>Número gerado: {numeroAleatorio}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f0f0f0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  resultado: {
    fontSize: 32,
    fontWeight: 'bold',
    marginTop: 20,
    color: '#2c3e50',
  },
});
