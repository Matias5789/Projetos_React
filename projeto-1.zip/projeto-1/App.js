import { View, Text, Image } from 'react-native';

function App(){
  
  return(
    <View>

    <Image
          source={{ uri: 'https://th.bing.com/th/id/OIP.o8ZJX1t6ZYoBRcngpyp4mAHaFj?rs=1&pid=ImgDetMain'}}
          style={{ width: 200, height: 200}}
        />

    <Text style={{color: '#0000FF', fontSize: 20}}>Dados Pessoais</Text>
    <Text>Nome: Marina Duarte Camaño Ramos</Text>
    <Text>Idade: 26 anos</Text>
    <Text>CEP: Santos, SP</Text>
    <Text style={{color: '#32CD32', fontSize: 20}}>Formação</Text>
    <Text>Jornalismo</Text>
    <Text>Sistemas para Internet</Text>
    <Text style={{color: '#FF00FF', fontSize: 20}}>Experiência</Text>
    <Text>Redação</Text>
    <Text>Assessoria de Imprensa</Text>
    <Text>UI/UX</Text>
    <Text>Gestão de Performance</Text>
    </View>
  )
}

export default App