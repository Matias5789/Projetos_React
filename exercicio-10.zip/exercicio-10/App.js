import React, { useState } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  Text,
  Switch,
  TextInput,
  Pressable
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import Slider from '@react-native-community/slider';

export default function App() {
  const [nome, setNome] = useState('');
  const [idade, setIdade] = useState('');
  const [sexo, setSexo] = useState('');
  const [escolaridade, setEscolaridade] = useState('');
  const [limite, setLimite] = useState(200);
  const [brasileiro, setBrasileiro] = useState(false);
  const [exibirDados, setExibirDados] = useState(false);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Abertura de Conta</Text>

      <Text>Nome:</Text>
      <TextInput
        style={styles.input}
        value={nome}
        onChangeText={setNome}
        placeholder="Digite seu nome"
      />

      <Text>Idade:</Text>
      <TextInput
        style={styles.input}
        value={idade}
        onChangeText={setIdade}
        placeholder="Digite sua idade"
        keyboardType="numeric"
      />

      <Text>Sexo:</Text>
      <Picker
        selectedValue={sexo}
        style={styles.picker}
        onValueChange={(itemValue) => setSexo(itemValue)}
      >
        <Picker.Item label="Selecione" value="" />
        <Picker.Item label="Masculino" value="Masculino" />
        <Picker.Item label="Feminino" value="Feminino" />
        <Picker.Item label="Outro" value="Outro" />
      </Picker>

      <Text>Escolaridade:</Text>
      <Picker
        selectedValue={escolaridade}
        style={styles.picker}
        onValueChange={(itemValue) => setEscolaridade(itemValue)}
      >
        <Picker.Item label="Selecione" value="" />
        <Picker.Item label="Ensino Fundamental" value="Fundamental" />
        <Picker.Item label="Ensino Médio" value="Médio" />
        <Picker.Item label="Ensino Superior" value="Superior" />
        <Picker.Item label="Pós-graduação" value="Pós" />
      </Picker>

      <Text>Limite: {limite.toFixed(0)}</Text>
      <Slider
        style={{ width: '100%', height: 40 }}
        minimumValue={0}
        maximumValue={1000}
        step={50}
        value={limite}
        onValueChange={setLimite}
      />

      <View style={styles.switchContainer}>
        <Text>Brasileiro:</Text>
        <Switch
          value={brasileiro}
          onValueChange={setBrasileiro}
        />
      </View>

      <Pressable style={styles.button} onPress={() => setExibirDados(true)}>
        <Text style={styles.buttonText}>Confirmar</Text>
      </Pressable>

      {exibirDados && (
        <View style={styles.dadosContainer}>
          <Text style={styles.dadosTitulo}>Dados informados:</Text>
          <Text>Nome: {nome}</Text>
          <Text>Idade: {idade}</Text>
          <Text>Sexo: {sexo}</Text>
          <Text>Escolaridade: {escolaridade}</Text>
          <Text>Limite: {limite.toFixed(0)}</Text>
          <Text>Brasileiro: {brasileiro ? 'Sim' : 'Não'}</Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingBottom: 40,
  },
  titulo: {
    fontSize: 25,
    color: 'red',
    marginBottom: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    borderBottomWidth: 1,
    marginBottom: 10,
    padding: 5,
  },
  picker: {
    height: 50,
    width: '100%',
    marginBottom: 10,
  },
  switchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    gap: 10,
  },
  button: {
    backgroundColor: '#cce5ff',
    padding: 10,
    alignItems: 'center',
    marginVertical: 20,
    borderWidth: 1,
    borderColor: '#007bff',
  },
  buttonText: {
    fontWeight: 'bold',
  },
  dadosContainer: {
    marginTop: 20,
  },
  dadosTitulo: {
    color: 'blue',
    fontWeight: 'bold',
    marginBottom: 10,
  },
});
