import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet } from 'react-native';

export default function App() {
  const [precoAlcool, setPrecoAlcool] = useState('');
  const [precoGasolina, setPrecoGasolina] = useState('');
  const [resultado, setResultado] = useState('');

  const calcularVantagem = () => {
    const precoEtanol = parseFloat(precoAlcool);
    const precoGaso = parseFloat(precoGasolina);

    if (isNaN(precoEtanol) || isNaN(precoGaso)) {
      setResultado('Por favor, insira valores válidos para os preços.');
      return;
    }

    const relacao = precoEtanol / precoGaso;

    if (relacao < 0.7) {
      setResultado('Álcool é mais vantajoso!');
    } else {
      setResultado('Gasolina é mais vantajosa!');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora de Vantagem: Álcool vs Gasolina</Text>

      <TextInput
        style={styles.input}
        keyboardType="numeric"
        placeholder="Preço do Álcool (R$)"
        value={precoAlcool}
        onChangeText={setPrecoAlcool}
      />

      <TextInput
        style={styles.input}
        keyboardType="numeric"
        placeholder="Preço da Gasolina (R$)"
        value={precoGasolina}
        onChangeText={setPrecoGasolina}
      />

      <Button title="Calcular" onPress={calcularVantagem} />

      {resultado !== '' && <Text style={styles.result}>{resultado}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f8f8f8',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
    fontSize: 16,
  },
  result: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    color: '#2c3e50',
  },
});
