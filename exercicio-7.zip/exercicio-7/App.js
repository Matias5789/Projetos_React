import React, { Component } from 'react';
import { View, StyleSheet, ScrollView, Text, Image } from 'react-native';




function App(){
let img1 = 'https://www.yamaha-motor.com.br/file/v8455595307359693098/products/lateral-supersport-r15-abs-30133-fx01-img-01-v02-desktop.jpg';
let img2 = 'https://www.yamaha-motor.com.br/file/v5810760876702565008/products/lateral-esportivas-r3-connected-30140-fx02-img-01-v01.jpg';
let img3 = 'https://www.yamaha-motor.com.br/file/v7565375494281994791/products/lateral-mtseries-mt03-connected-abs-30141-fx02-img-01-v01.jpg';


  return(
    <View style={styles.container}>
      <Text style={styles.anuncio}> Anuncio </Text>
      <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
        <View style={styles.box1}>
        <Image
          source={{ uri: img1 }}
          style={{ width: 250, height: 250, borderRadius: 20}}
        />
        <Text style={styles.produto}> A nova moto carenada da Yamaha, a YZF-R15 ABS, estreia a categoria de motos sportfun, esportivas e divertidas. </Text>
        <Text style={styles.preco}> O Valor é de R$ 23.260,00 </Text>
        </View>
        <View style={styles.box2}>
        <Image
          source={{ uri: img2 }}
          style={{ width: 250, height: 250, borderRadius: 20}}
        />
        <Text style={styles.produto}> Mais esportiva, mais aerodinâmica e muito mais emocionante. Com seu motor bicilíndrico de 321cc. </Text>
        <Text style={styles.preco}> O Valor é de R$ 38.490,00 </Text>

        </View>
        <View style={styles.box3}>
        <Image
          source={{ uri: img3 }}
          style={{ width: 250, height: 250, borderRadius: 20}}
        />
        <Text style={styles.produto}> A nova MT-03 foi projetada para oferecer mais conforto e controle sem abrir mão da performance </Text>
        <Text style={styles.preco}> O Valor é de R$ 35.490,00 </Text>
        </View>
        
      </ScrollView>
    </View>
  )
}




const styles = StyleSheet.create({
  container:{
    flex: 1
  },
  anuncio:{
    fontSize: 40,
    textAlign: 'center',
    color: 'red',
    marginBottom: 20,
  },
  box1:{
    backgroundColor: 'lightgray',
    height: 550,
    width: 300,
    padding: 20,
    marginRight: 20,
    borderRadius: 20,
  },
  box2:{
    backgroundColor: 'lightgray',
    height: 550,
    width: 300,
    padding: 20,
    borderRadius: 20,
    marginRight: 20,
  },
  box3:{
    backgroundColor: 'lightgray',
    height: 550,
    width: 300,
    padding: 20,
    borderRadius: 20,
  },
  produto:{
    fontSize: 20,
    padding: 10,
  },
  preco:{
    fontSize: 30,
    fontWeight: 'Bold',
    textAlign: 'center',
    padding: 10,
  },
})




export default App;

