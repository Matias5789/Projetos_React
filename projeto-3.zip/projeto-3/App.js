import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet } from 'react-native';

export default function App() {
  const [numero1, setNumero1] = useState('');
  const [numero2, setNumero2] = useState('');
  const [resultado, setResultado] = useState(null);

  const multiplicar = () => {
    const num1 = parseFloat(numero1);
    const num2 = parseFloat(numero2);
    if (!isNaN(num1) && !isNaN(num2)) {
      setResultado(num1 * num2);
    } else {
      setResultado('Por favor, insira números válidos.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Multiplicador de Números</Text>

      <TextInput
        style={styles.input}
        keyboardType="numeric"
        placeholder="Número 1"
        value={numero1}
        onChangeText={setNumero1}
      />
      
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        placeholder="Número 2"
        value={numero2}
        onChangeText={setNumero2}
      />

      <Button title="Multiplicar" onPress={multiplicar} />

      {resultado !== null && (
        <Text style={styles.result}>Resultado: {resultado}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
    fontSize: 16,
  },
  result: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
  },
});
