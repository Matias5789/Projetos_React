import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function ContadorPessoas() {
  const [contador, setContador] = useState(0);

  // Função para incrementar
  const incrementar = () => {
    setContador(contador + 1);
  };

  // Função para decrementar
  const decrementar = () => {
    if (contador > 0) {
      setContador(contador - 1);
    }
  };

  // Função para zerar
  const zerar = () => {
    setContador(0);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Contador de Pessoas</Text>
      <Text style={styles.contador}>{contador}</Text>

      <View style={styles.buttonContainer}>
        <Button title="Incrementar" onPress={incrementar} color="#27ae60" />
        <Button title="Decrementar" onPress={decrementar} color="#e74c3c" />
        <Button title="Zerar" onPress={zerar} color="#3498db" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 20,
  },
  contador: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#e74c3c',
    textAlign: 'center',
    marginBottom: 30,
  },
  buttonContainer: {
    width: '100%',
    justifyContent: 'space-around',
    flexDirection: 'row',
    marginTop: 20,
  },
});
