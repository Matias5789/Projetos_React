import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet } from 'react-native';

export default function App() {
  const [peso, setPeso] = useState('');
  const [altura, setAltura] = useState('');
  const [resultado, setResultado] = useState('');

  const calcularIMC = () => {
    const pesoValor = parseFloat(peso);
    const alturaValor = parseFloat(altura);

    if (isNaN(pesoValor) || isNaN(alturaValor) || alturaValor <= 0 || pesoValor <= 0) {
      setResultado('Por favor, insira valores válidos para peso e altura.');
      return;
    }

    const imc = pesoValor / (alturaValor * alturaValor);
    let classificacao = '';

    if (imc < 18.5) {
      classificacao = 'Abaixo do peso';
    } else if (imc >= 18.5 && imc <= 24.9) {
      classificacao = 'Peso normal';
    } else if (imc >= 25 && imc <= 29.9) {
      classificacao = 'Sobrepeso';
    } else if (imc >= 30 && imc <= 39.9) {
      classificacao = 'Obesidade';
    } else {
      classificacao = 'Obesidade grave';
    }

    setResultado(`IMC: ${imc.toFixed(2)}\nClassificação: ${classificacao}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora de IMC</Text>

      <TextInput
        style={styles.input}
        keyboardType="numeric"
        placeholder="Peso (kg)"
        value={peso}
        onChangeText={setPeso}
      />

      <TextInput
        style={styles.input}
        keyboardType="numeric"
        placeholder="Altura (m)"
        value={altura}
        onChangeText={setAltura}
      />

      <Button title="Calcular IMC" onPress={calcularIMC} />

      {resultado !== '' && <Text style={styles.result}>{resultado}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f8f8f8',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
    fontSize: 16,
  },
  result: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    color: '#2c3e50',
  },
});
