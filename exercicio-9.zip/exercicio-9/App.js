import React, { Component, useState } from 'react';
import { View, StyleSheet, FlatList, Text } from 'react-native';




function App(){


  let initial_feed = [
        {id: 1, funcao: 'Desenvolvedor de Software', salario: 3.500, descricao: 'Cria, testa, e mantém programas de computador, aplicativos, e sistemas.' , contato: '(11) 951753-2846'},
        {id: 2, funcao: 'Desenvolvedor Mobile', salario: 4.000, descricao: 'Cria aplicativos para dispositivos móveis, como smartphones e tablets. Ele escreve códigos, testa, depura e mantém os aplicativos.' , contato: '(11) 951753-2846'},
        {id: 3, funcao: 'Analista de Dados', salario: 3.700, descricao: 'Coleta, analisa e interpreta dados para ajudar empresas a tomar decisões baseadas em evidências.' , contato: '(11) 951753-2846'},
        {id: 4, funcao: 'Web Design', salario: 2.800, descricao: 'Projetar o layout e a estética de sites. Isso inclui codificação, design, construção de interface e navegação.' , contato: '(11) 951753-2846'},
      
      ]


  const [feed, setFeed] = useState(initial_feed)


  return(
    <View style={styles.container}>
      <Text style={styles.vagas}> Vagas </Text>
      <FlatList
      data={feed}
      keyExtractor={(item) => item.id}
      renderItem={ ({item}) => <Vaga data={item}/>}
      />
    </View>
  )
}




const styles = StyleSheet.create({
  container:{
    flex: 1
  },
  areaVaga:{
    backgroundColor: 'lightgray',
    height: 300,
    marginBottom: 15,
    padding: 20,
    borderRadius: 50,
  },
  vagas:{
    color: 'red',
    fontSize: 50,
    textAlign: 'center',
  },
  funcao:{
    color: 'blue',
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  salario: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  descricao: {
    fontSize: 20,
    marginBottom: 10,
    
  },
  contato: {
    fontSize: 20,
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },



})




export default App;




function Vaga (props){
  return(
      <View style={styles.areaVaga}>
        <Text style={styles.funcao}> {props.data.funcao} </Text>
        <Text style={styles.salario}> Salario: {props.data.salario} </Text>
        <Text style={styles.descricao}> Descricao: {props.data.descricao} </Text>
        <Text style={styles.contato}> Contato: {props.data.contato} </Text>
      </View>
  );
}


